<?php

function homePageStyles() {
?>
<style type="text/css">
  .ho{
    color: #fff;
    text-decoration: none;
    background-color: #ff7700;
  }
</style>
<?php
}

function homePlaylistStyles() {
?>
<style type="text/css">
  .cat{
    color: #fff;
    text-decoration: none;
    background-color: #ff7700;
  }
  .es-carousel ul{
    display:block;
  }
</style>
<?php
}

?>